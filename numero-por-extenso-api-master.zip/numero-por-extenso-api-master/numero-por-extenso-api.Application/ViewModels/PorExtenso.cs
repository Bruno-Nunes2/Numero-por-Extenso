﻿namespace numero_por_extenso_api.Application.ViewModels
{
    public class PorExtenso
    {
        public string Extenso { get; set; }
    }
}
